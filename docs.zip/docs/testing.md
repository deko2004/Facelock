# Testing

## Run the suite

```bash
cd /home/deku/FaceRecognitionProject
venv/bin/python -m pytest
```

Observed result:

```text
90 passed (about 15s on the development machine)
```

The suite does not require a physical webcam. It uses temporary databases, keys
and images, so it does not modify the real `database/` or `results/` folders.

## What is covered

| Area | Tests |
|---|---|
| Models | Model loading, detection, no-face handling, multiple faces, embedding shape, self-similarity, different-person scores, missing-model errors |
| Matching | Threshold boundary, known cosine values, shape mismatch, zero vectors, result text, threshold clamping, 1:N best-match identification |
| Image processing | Valid/missing/unsupported/corrupt images, quality pass/reject, annotation does not mutate the input, custom face labels, save |
| Security | User ID and display-name validation, Fernet round-trip, wrong-key failure, key permissions, safe unlink |
| Database | Add/get/list/count/delete, duplicate rejection, missing user, invalid ID, non-finite embedding, encryption at rest, file permissions, corrupted token, audit log |
| Enrolment | Consent, duplicate, invalid ID, no face, missing file, frame enrolment, success path |
| Verification | Same person, different person, unknown user, no face, deletion, shared threshold update |
| Evaluation | Confusion matrix, FAR/FRR/accuracy/precision/recall, missing/empty dataset, demo dataset, no-genuine-pair case, CSV and chart export |
| Camera | Device enumeration shape, read-before-open error, open failure, mocked open/read/release, probe success/failure, worker name labels |
| Settings | Threshold clamp, save/load, invalid/missing settings fallback |
| GUI | Every page constructs, shows and hides under a real Tk display; background results are delivered on the main thread |

## GUI test

`tests/test_gui_smoke.py` creates the main window with a temporary context,
visits every page in `PAGE_CLASSES`, calls `on_show()` and closes the application.
It is skipped automatically when neither `DISPLAY` nor `WAYLAND_DISPLAY` is set.

Run it explicitly:

```bash
DISPLAY=:1 venv/bin/python -m pytest tests/test_gui_smoke.py -v
```

## Evaluation test

`tests/test_evaluation.py` runs the real YuNet/SFace pipeline on
`images/eval_demo/` and asserts the observed smoke-test shape:

- 5 usable images
- 4 identities
- 1 genuine pair
- 9 impostor pairs
- FAR and FRR available and zero at threshold `0.363`
- 101-point threshold sweep
- CSV and PNG chart exports

This is a regression test for the pipeline, not a performance benchmark.

## Manual checks

The automated suite cannot replace a manual GUI/camera check:

1. Run `./run.sh --check`.
2. Launch `./run.sh` on a desktop session.
3. Open each page.
4. Enrol a test user from an image.
5. Verify the same image and a different person's image.
6. Start the live camera, confirm preview/FPS, then stop.
7. Delete the test user and confirm the count decreases.
8. Run the evaluation page on `images/eval_demo`.

## Known test limitations

- The camera tests use a fake `cv2.VideoCapture`; they do not validate a real
  device driver.
- The GUI test constructs pages but does not automate every button path.
- There is no presentation-attack or liveness test because no PAD component
  exists.
- There is no demographic fairness test; the sample is too small.
- The evaluation result is a pipeline smoke test, not a biometric benchmark.
- Security tests cover the implemented controls, not a full penetration test.

## Interpreting failures

- Missing models: place both ONNX files in `models/`.
- Tkinter display error: run in a desktop session or forward X11.
- `cryptography` missing: `venv/bin/pip install -r requirements.txt`.
- Evaluation test failure after changing thresholds: the expected FAR/FRR values
  are tied to the bundled sample and threshold `0.363`; update the test only if
  the experimental setup intentionally changes.
